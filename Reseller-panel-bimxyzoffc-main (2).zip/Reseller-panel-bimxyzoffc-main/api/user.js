export const users = [
  {
    "username": "Admin",
    "password": "Admin089"
  },
  {
    "username": "Gondes089",
    "password": "089630"
  },
  {
    "username": "xccv",
    "password": "xccv333"
  },
  {
    "username": "Akmal",
    "password": "17"
  },
  {
    "username": "Starla123",
    "password": "Starla123"
  },
  {
    "username": "Ryu",
    "password": "Ryu08"
  },
  {
    "username": "hayabusa",
    "password": "store"
  },
  {
    "username": "Yann321",
    "password": "Qwerty1"
  },
  {
    "username": "LemmFdx",
    "password": "Lemmfskapnl"
  },
  {
    "username": "valak",
    "password": "therealm135"
  },
  {
    "username": "Zarr",
    "password": "Zarr888"
  },
  {
    "username": "dikzajalah",
    "password": "dikzajalah"
  },
  {
    "username": "pias",
    "password": "kontol112"
  },
  {
    "username": "auuu",
    "password": "hiag"
  },
  {
    "username": "rdillnh",
    "password": "987654312"
  },
  {
    "username": "BOB",
    "password": "DUCK"
  },
  {
    "username": "oscarNotbound",
    "password": "oscarvx"
  },
  {
    "username": "hafiz",
    "password": "hafizstore"
  },
  {
    "username": "Ayam321",
    "password": "Cung321"
  },
  {
    "username": "ChisaStore",
    "password": "ChisaStore0_1"
  },
  {
    "username": "rapzganteng",
    "password": "njir"
  },
  {
    "username": "lutfi",
    "password": "2008"
  },
  {
    "username": "PAYZZ",
    "password": "PAYZZ27"
  },
  {
    "username": "Ranz123",
    "password": "wirasukaayam"
  },
  {
    "username": "aboo",
    "password": "ab00"
  },
  {
    "username": "4AS",
    "password": "4ASSS"
  },
  {
    "username": "malvinz",
    "password": "malvin0101"
  },
  {
    "username": "DanAjah",
    "password": "7583"
  },
  {
    "username": "Syafik",
    "password": "Syafik123"
  },
  {
    "username": "Ridho",
    "password": "1"
  },
  {
    "username": "nesa",
    "password": "nesastr"
  },
  {
    "username": "Vanz",
    "password": "1"
  },
  {
    "username": "Vynx",
    "password": "Vynx"
  },
  {
    "username": "sinz",
    "password": "sinz01"
  },
  {
    "username": "Zero",
    "password": "Zero"
  },
  {
    "username": "Kalz",
    "password": "Kalz"
  },
  {
    "username": "fallzyabcd",
    "password": "ADMIN01"
  },
  {
    "username": "Fakut",
    "password": "Fitra143"
  },
  {
    "username": "dane",
    "password": "dane4545"
  },
  {
    "username": "mad y adhonx",
    "password": "300811"
  },
  {
    "username": "Kimz",
    "password": "Kimz11"
  },
  {
    "username": "Arjuna",
    "password": "Arjuna"
  },
  {
    "username": "noctora",
    "password": "noctora1"
  },
  {
    "username": "fiz",
    "password": "Diz"
  },
  {
    "username": "refal",
    "password": "27052013"
  },
  {
    "username": "Nanda strx",
    "password": "Nanda strx"
  },
  {
    "username": "Dejevi",
    "password": "020606"
  },
  {
    "username": "dejevi",
    "password": "dejevi"
  },
  {
    "username": "11",
    "password": "22"
  },
  {
    "username": "Pannn",
    "password": "Pannnstecu"
  },
  {
    "username": "Ndra",
    "password": "Ndra"
  },
  {
    "username": "Ambakuin",
    "password": "2010"
  },
  {
    "username": "Fajar",
    "password": "Fajar"
  },
  {
    "username": "aldikece",
    "password": "aldiawan"
  },
  {
    "username": "Wongirengjembuten",
    "password": "Asuitel"
  },
  {
    "username": "Sadzz",
    "password": "123"
  },
  {
    "username": "FyzzRQ",
    "password": "fyzzrq28"
  },
  {
    "username": "COSTASTURR",
    "password": "Nando*123"
  },
  {
    "username": "BIMZZ",
    "password": "BIMZZ123"
  },
  {
    "username": "manzx",
    "password": "manzx15"
  },
  {
    "username": "Sanfly",
    "password": "IhsanAtp0990"
  },
  {
    "username": "ska",
    "password": "191019"
  },
  {
    "username": "Yasid",
    "password": "DevvVip"
  },
  {
    "username": "PannnCpanel",
    "password": "PannnStecu"
  },
  {
    "username": "Aditya",
    "password": "27052013"
  },
  {
    "username": "anomali",
    "password": "firja778"
  },
  {
    "username": "XIAREZZ",
    "password": "1111"
  },
  {
    "username": "DEVIN",
    "password": "Devin05"
  },
  {
    "username": "Wibow",
    "password": "Tiko"
  },
  {
    "username": "Bimxyz",
    "password": "08579713"
  },
  {
    "username": "rafaelganteng",
    "password": "anuadalahpokoknya1"
  },
  {
    "username": "dejevii",
    "password": "dejevii"
  },
  {
    "username": "devv",
    "password": "101011"
  },
  {
    "username": "Kazeya-kun",
    "password": "123qweasdzxc"
  },
  {
    "username": "BOTJAGA GB",
    "password": "Bot jaga grup"
  },
  {
    "username": "rorr",
    "password": "0838"
  },
  {
    "username": "nzy",
    "password": "08123"
  },
  {
    "username": "adukhy",
    "password": "adukhy"
  },
  {
    "username": "bjorkanism",
    "password": "tikacantik30"
  }
];