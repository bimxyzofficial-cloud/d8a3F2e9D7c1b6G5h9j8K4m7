export const PANEL_URL = "https://pterodactyl.me.bimxyz.my.id";
export const API_KEY = "ptla_2uunQ91FxZfwYL0JGhpxKsr5GGlTh0vzS7vQmzcWyMp";
export const NODE_ID = "1";
export const NEST_ID = "5";
export const EGG_ID = "15";
export const DOCKER_IMG = "ghcr.io/parkervcp/yolks:nodejs_20";
